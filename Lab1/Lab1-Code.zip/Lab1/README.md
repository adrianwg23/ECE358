# ECE358 - Lab 1

## Authors:
- Adrian Wong (20720975)
- Enoch Tang (20720705)

## Run Script
The script `lab1.py` is compatibable with all libraries available by default on `eceubuntu` and does not require installing additional libs.

To run script, simply execute:
```
make run
```
